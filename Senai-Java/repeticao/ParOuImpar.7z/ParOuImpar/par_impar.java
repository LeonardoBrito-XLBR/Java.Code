package ex02;


public class par_impar {
    public static void main(String[] args) {
            


        // NUMEROS PARES
        for (int i =1; i <=51; i++){
             if (i%2 != 0) {
                System.out.println(i);
         
           }
        }   
        
        //NUMEROS PARES
        for (int i =52; i <=100; i++){
            if (i%2 == 0){
                System.out.println(i);
            }
        }
    }
}